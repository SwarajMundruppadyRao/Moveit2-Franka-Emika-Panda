#include <memory>
#include <chrono>
#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>

int main(int argc, char * argv[])
{
  // Initialize ROS and create the Node
  rclcpp::init(argc, argv);
  auto const node = std::make_shared<rclcpp::Node>("swaraj_120127007",rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true));

  // Create a ROS logger
  auto const logger = rclcpp::get_logger("swaraj_120127007");

  // Next step goes here
  // Create the MoveIt MoveGroup Interface
  using moveit::planning_interface::MoveGroupInterface;
  auto move_group_interface = MoveGroupInterface(node, "panda_arm");

  

// Set a target Pose
  auto const target_pose1 = []{
    geometry_msgs::msg::Pose t1;
    t1.orientation.w = 0.0;
    t1.orientation.x = 0.3826384;
    t1.orientation.y = 0.9238795;
    t1.orientation.z = 0.0;
    t1.position.x = 0.6;
    t1.position.y = -0.3;
    t1.position.z = 0.1;
    return t1;
  }();
  move_group_interface.setPoseTarget(target_pose1);

// Create a plan to that target pose
  auto const [success, plan] = [&move_group_interface]{
    moveit::planning_interface::MoveGroupInterface::Plan t1;
    auto const ok = static_cast<bool>(move_group_interface.plan(t1));
    return std::make_pair(ok, t1);
  }();

// Execute the plan
//Plan - Open Gripper, Move to target pose1, Close Gripper, Move to target pose2, Open Gripper, Move to target home pose 
  if(success) {
   std::this_thread::sleep_for(std::chrono::seconds(5));
   auto move_group_interface2 = MoveGroupInterface(node, "hand");
   RCLCPP_INFO(logger, "Opening the Gripper");
   move_group_interface2.setNamedTarget("open");
   bool success_gripper = static_cast<bool>(move_group_interface2.move());
   std::this_thread::sleep_for(std::chrono::seconds(5));
   if (!success_gripper) {
      RCLCPP_ERROR(logger, "Failed to open the gripper!");
    }
   // Execute the plan to target pose1
   RCLCPP_INFO(logger, "Moving to target pose 1");
   move_group_interface.execute(plan);
   std::this_thread::sleep_for(std::chrono::seconds(5));
   RCLCPP_INFO(logger, "Closing the Gripper");
   move_group_interface2.setNamedTarget("close");
   bool success_gripper2 = static_cast<bool>(move_group_interface2.move());
   std::this_thread::sleep_for(std::chrono::seconds(5));
   if (!success_gripper2) {
      RCLCPP_ERROR(logger, "Failed to open the gripper!");
    }
  
  } else {
    RCLCPP_ERROR(logger, "Planing failed!");
  }
  //Define the target pose2
  auto const target_pose2 = []{
    geometry_msgs::msg::Pose t2;
    t2.orientation.w = 0.0;
    t2.orientation.x = 0.3826384;
    t2.orientation.y = 0.9238795;
    t2.orientation.z = 0.0;
    t2.position.x = -0.5;
    t2.position.y = -0.1;
    t2.position.z = 0.2;
    return t2;
  }();
  //If success move to target pose2
  move_group_interface.setPoseTarget(target_pose2);
  auto const [success2, plan2] = [&move_group_interface]{
    moveit::planning_interface::MoveGroupInterface::Plan t2;
    auto const ok = static_cast<bool>(move_group_interface.plan(t2));
    return std::make_pair(ok, t2);
  }(); 
  if(success2) {
    RCLCPP_INFO(logger, "Moving to target pose 2");
    move_group_interface.execute(plan2);
    std::this_thread::sleep_for(std::chrono::seconds(5));
    RCLCPP_INFO(logger, "Opening the Gripper");
    auto move_group_interface2 = MoveGroupInterface(node, "hand");
    move_group_interface2.setNamedTarget("open");
    bool success_gripper3 = static_cast<bool>(move_group_interface2.move());
    std::this_thread::sleep_for(std::chrono::seconds(5));
    if (!success_gripper3) {
      RCLCPP_ERROR(logger, "Failed to close the gripper!");
    }
  } else {
    RCLCPP_ERROR(logger, "Planing failed!");
  }
  //Define the target home pose
  auto const target_pose3 = []{
    geometry_msgs::msg::Pose home;
    home.orientation.w = 0.0;
    home.orientation.x = 0.3826384;
    home.orientation.y = 0.9238795;
    home.orientation.z = 0.0;
    home.position.x = 0.5;
    home.position.y = 0.0;
    home.position.z = 0.75;
    return home;
  }();
  move_group_interface.setPoseTarget(target_pose3);
  auto const [success3, plan3] = [&move_group_interface]{
    moveit::planning_interface::MoveGroupInterface::Plan home;
    auto const ok = static_cast<bool>(move_group_interface.plan(home));
    return std::make_pair(ok, home);
  }();
  if(success3) {
    RCLCPP_INFO(logger, "Moving to home pose");
    move_group_interface.execute(plan3);

    auto move_group_interface2 = MoveGroupInterface(node, "hand");
    move_group_interface2.setNamedTarget("close");
    bool success_gripper3 = static_cast<bool>(move_group_interface2.move());
    if (!success_gripper3) {
      RCLCPP_ERROR(logger, "Failed to close the gripper!");
    }
    std::this_thread::sleep_for(std::chrono::seconds(5));
    RCLCPP_INFO(logger, "Task Completed!, Reached to the home pose");
    RCLCPP_INFO(logger, "Shutting down the node!");
    
  } else {
    RCLCPP_ERROR(logger, "Planing failed!");
  }
  // Shutdown ROS
  rclcpp::shutdown();
  return 0;
}

